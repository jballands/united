# united

![](http://i.imgur.com/s9aArg6.png)

Slack channel overbooked? Make room for higher paying customers and crew in Slack.

*© 2017 Jonathan Ballands*

## Usage

In the Slack channel you want to free up space in, invoke this slash command:

```
/united
```

This will call up the authorities to remove a random user from the Slack channel,
freeing up one spot. No need to feel bad about it! You're just doing your job.

## Installation

*I need to update the readme for the new architecture...*
