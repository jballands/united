'use strict';

//
//  jballands/united
//  index.js
//
//  An AWS Lambda function that makes room in an overbooked Slack channel for
//  higher paying customers and crew, whether you like it or not.
//
//  © 2017 Jonathan Ballands
//

const aws = require('aws-sdk');
const axios = require('axios');
const process = require('process');
const _random = require('lodash.random');
const qs = require('querystring');

const ACCESS_TOKEN = process.env.ACCESS_TOKEN;
let decrypted;

const catchphrase = process.env.CATCHPHRASE || 'U stay in the seato, u get a beato';

// -----------------------------------------------------------------------------
//  LAMBDA
// -----------------------------------------------------------------------------

exports.handler = (event, context, callback) => {
    const params = qs.parse(event.postBody)
    const channelId = params['channel_id'];

    // U stay in the seato, u get a beato
    getAccessToken()
        .then(token => getChannelMembers(decrypted, channelId))
        .then(members => chooseRandomMember(members))
        .then(memberId => kickMember(decrypted, channelId, memberId))
        .then(memberId => getMemberIMCHannel(decrypted, memberId))
        .then(channelId => messageMember(decrypted, channelId))
        .then(
            () => callback(null, {
                response_type: 'in_channel',
                text: catchphrase
            })
        )
        .catch(err => {
            console.error(err);
            return callback(null, err);
        });
};

// -----------------------------------------------------------------------------
//  HELPERS
// -----------------------------------------------------------------------------

//
//  Returns a promise that attempts to resolve the access token from AWS.
//
function getAccessToken() {
    return new Promise((resolve, reject) => {
        if (decrypted) {
            return resolve(decrypted);
        }
        else {
            const kms = new aws.KMS();
            kms.decrypt({ CiphertextBlob: new Buffer(ACCESS_TOKEN, 'base64') }, (err, data) => {
                if (err) {
                    console.error('Decrypt error: ', err);
                    return reject(err);
                }
                decrypted = data.Plaintext.toString('ascii');
                return resolve(decrypted);
            });
        }
    });
}

//
//  Returns a promise that attempts to resolve members of a channel.
//
function getChannelMembers(accessToken, channelId) {
    return new Promise((resolve, reject) => {
        const args = {
            token: accessToken,
            channel: channelId
        };

        const visibility = channelId.startsWith('G') ?
            { endpoint: 'groups.info', raw: 'group' } :
            { endpoint: 'channels.info', raw: 'channel' };

        axios.post(`https://slack.com/api/${visibility.endpoint}?${qs.stringify(args)}`)
            .then(res => {
                const data = res.data;
                if (data.ok !== true) {
                    console.error(`Response was not ok!! ${JSON.stringify(data)}`);
                    return reject('Arg. I couldn\'nt get the flight roster from Slack. Next time...');
                }

                return resolve(data[visibility.raw].members);
            })
            .catch(err => reject(err));
    });
}

//
//  Returns a promise that attempts to resolve to the victim user.
//
function chooseRandomMember(members) {
    return new Promise((resolve, reject) => {
        if (!members.length || members.length <= 0) {
            return reject('I can\'t kick out people that don\'t exist.');
        }
        if (members.length === 1) {
            return reject('I can\'t kick you out if you\'re the only member of a channel (LOL).');
        }
        return resolve(members[_random(members.length - 1)]);
    });
}

//
//  Returns a promise that attempts to resolve after kicking the victim from the
//  Slack channel.
//
function kickMember(accessToken, channelId, userId) {
    return new Promise((resolve, reject) => {
        const args = {
            token: accessToken,
            channel: channelId,
            user: userId
        };

        const visibility = channelId.startsWith('G') ?
            { endpoint: 'groups.kick', raw: 'group' } :
            { endpoint: 'channels.kick', raw: 'channel' };

        axios.post(`https://slack.com/api/${visibility.endpoint}?${qs.stringify(args)}`)
            .then(res => {
                const data = res.data;
                if (data.ok !== true) {
                    console.error(`Response was not ok!! ${JSON.stringify(data)}`);

                    // If it chose the invoker, reject it with a funny message
                    if (data.error === 'cant_kick_self') {
                        return reject('Looks like you got chosen... Too bad Slack won\'t let me kick you out. Try again?');
                    }
                    return reject('I couldn\'nt kick anyone out for some reason...');
                }
                return resolve(userId);
            })
            .catch(err => reject(err));
        });
}

//
//  
//
function getMemberIMCHannel(accessToken, userId) {
    return new Promise((resolve, reject) => {
        const args = {
            token: accessToken,
            user: userId
        };

        axios.post(`https://slack.com/api/im.open?${qs.stringify(args)}`)
            .then(res => {
                const data = res.data;
                if (data.ok !== true) {
                    console.error(`Response was not ok!! ${JSON.stringify(data)}`);
                    return reject('I couldn\'t fetch information about the kicked user...');
                }
                if (!data.channel || !data.channel.id) {
                    console.error(`Unexpected data was returned!! ${JSON.stringify(data)}`);
                    return reject('I couldn\'t fetch information about the kicked user...');
                }

                return resolve(data.channel.id);
            })
            .catch(err => reject(err));
        });
}

//
//  
//
function messageMember(accessToken, channelId) {
    return new Promise((resolve, reject) => {
        const args = {
            token: accessToken,
            channel: channelId,
            text: catchphrase
        };

        axios.post(`https://slack.com/api/chat.postMessage?${qs.stringify(args)}`)
            .then(res => {
                const data = res.data;
                if (data.ok !== true) {
                    console.error(`Response was not ok!! ${JSON.stringify(data)}`);
                    return reject('I couldn\'t message the user who got kicked...');
                }
                return resolve();
            })
            .catch(err => reject(err));
        });
}
